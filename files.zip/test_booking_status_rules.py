"""InkBound backend tests - booking status transition rules.

Clients may only cancel their own bookings (pending/confirmed).
Only the booking's artist may confirm, decline or complete.
declined / completed / cancelled are final.
"""
import os
from datetime import date, timedelta

import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") if os.environ.get(
    "EXPO_PUBLIC_BACKEND_URL"
) else "https://tattoo-spots.preview.emergentagent.com"

API = f"{BASE_URL}/api"

CUSTOMER = {"email": "customer@inkbound.com", "password": "Passw0rd!"}
ARTIST = {"email": "artist@inkbound.com", "password": "Passw0rd!"}


def auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module")
def customer_token(s):
    r = s.post(f"{API}/auth/login", json=CUSTOMER, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


@pytest.fixture(scope="module")
def artist_token(s):
    r = s.post(f"{API}/auth/login", json=ARTIST, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


@pytest.fixture()
def new_booking(s, customer_token):
    """Create a fresh pending booking on ar_1 at the first free slot on a spare future date."""
    for offset in range(40, 70):
        d = (date.today() + timedelta(days=offset)).isoformat()
        rs = s.get(f"{API}/bookings/slots", params={"artist_id": "ar_1", "date": d}, timeout=20)
        free = next((x["time"] for x in rs.json().get("slots", []) if x["available"]), None)
        if free:
            r = s.post(
                f"{API}/bookings",
                headers=auth(customer_token),
                json={"artist_id": "ar_1", "service_id": "sv_pl_1_0", "date": d, "time": free, "note": "TEST_status_rules"},
                timeout=20,
            )
            assert r.status_code == 200, r.text
            return r.json()["booking"]["id"]
    pytest.skip("No free slot found for ar_1")


def patch(s, booking_id, token, status):
    return s.patch(f"{API}/bookings/{booking_id}/status", headers=auth(token), json={"status": status}, timeout=20)


class TestStatusRules:
    def test_client_cannot_confirm_own_booking(self, s, customer_token, new_booking):
        assert patch(s, new_booking, customer_token, "confirmed").status_code == 403

    def test_client_cannot_decline_or_complete(self, s, customer_token, new_booking):
        assert patch(s, new_booking, customer_token, "declined").status_code == 403
        assert patch(s, new_booking, customer_token, "completed").status_code == 403

    def test_client_cannot_complete_after_artist_confirms(self, s, customer_token, artist_token, new_booking):
        assert patch(s, new_booking, artist_token, "confirmed").status_code == 200
        assert patch(s, new_booking, customer_token, "completed").status_code == 403

    def test_client_can_cancel_pending(self, s, customer_token, new_booking):
        r = patch(s, new_booking, customer_token, "cancelled")
        assert r.status_code == 200 and r.json()["booking"]["status"] == "cancelled"

    def test_artist_can_decline_pending(self, s, artist_token, new_booking):
        r = patch(s, new_booking, artist_token, "declined")
        assert r.status_code == 200 and r.json()["booking"]["status"] == "declined"

    def test_artist_cannot_complete_pending(self, s, artist_token, new_booking):
        assert patch(s, new_booking, artist_token, "completed").status_code == 403

    def test_artist_confirm_then_complete(self, s, artist_token, new_booking):
        assert patch(s, new_booking, artist_token, "confirmed").status_code == 200
        r = patch(s, new_booking, artist_token, "completed")
        assert r.status_code == 200 and r.json()["booking"]["status"] == "completed"

    def test_final_statuses_cannot_change(self, s, customer_token, artist_token, new_booking):
        assert patch(s, new_booking, customer_token, "cancelled").status_code == 200
        assert patch(s, new_booking, artist_token, "confirmed").status_code == 409
        assert patch(s, new_booking, customer_token, "cancelled").status_code == 409

    def test_invalid_status_rejected(self, s, artist_token, new_booking):
        assert patch(s, new_booking, artist_token, "banana").status_code == 400
