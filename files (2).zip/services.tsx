import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api/client";
import { Icon } from "@/src/components/Icon";
import { useToast } from "@/src/components/toast";
import { PrimaryButton } from "@/src/components/ui";
import { Service } from "@/src/types";
import { fonts, makeStyles, useTheme } from "@/src/theme";

type Data = { services: Service[]; default_deposit_percent: number };

// keep only digits and a single decimal point, max 2 decimals
function cleanMoney(t: string) {
  const v = t.replace(/[^0-9.]/g, "");
  const [whole, ...rest] = v.split(".");
  return rest.length ? `${whole}.${rest.join("").slice(0, 2)}` : whole;
}

export default function StudioServices() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data, isLoading } = useQuery({
    queryKey: ["studio", "services"],
    queryFn: () => api<Data>("/api/studio/services"),
  });

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Pressable testID="services-back" onPress={() => router.back()} style={styles.backBtn}>
          <Icon name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={styles.headerTitle}>Prices & deposits</Text>
        <View style={{ width: 42 }} />
      </View>

      {isLoading || !data ? (
        <View style={styles.center}><ActivityIndicator color={colors.brandPrimary} size="large" /></View>
      ) : (
        <KeyboardAwareScrollView
          contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40, gap: 14 }}
          showsVerticalScrollIndicator={false}
          bottomOffset={20}
        >
          <Text style={styles.sub}>
            Set what you charge for each service and the deposit clients pay to secure a slot. Leave the deposit empty to
            use the default ({data.default_deposit_percent}% of the price). New prices only apply to future bookings.
          </Text>
          {data.services.map((sv) => (
            <ServiceRow key={sv.id} service={sv} defaultPercent={data.default_deposit_percent} />
          ))}
        </KeyboardAwareScrollView>
      )}
    </View>
  );
}

function ServiceRow({ service, defaultPercent }: { service: Service; defaultPercent: number }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const qc = useQueryClient();

  const savedPrice = String(service.price ?? 0);
  const savedDeposit = service.deposit == null ? "" : String(service.deposit);
  const [price, setPrice] = useState(savedPrice);
  const [deposit, setDeposit] = useState(savedDeposit);

  // re-sync after a successful save / refetch
  useEffect(() => {
    setPrice(savedPrice);
    setDeposit(savedDeposit);
  }, [savedPrice, savedDeposit]);

  const priceNum = parseFloat(price);
  const dirty = price !== savedPrice || deposit !== savedDeposit;
  const defaultDeposit = Number.isFinite(priceNum) ? Math.round(priceNum * defaultPercent) / 100 : 0;

  const save = useMutation({
    mutationFn: (body: { price: number; deposit: number | null }) =>
      api(`/api/studio/services/${service.id}`, { method: "PUT", body: JSON.stringify(body) }),
    onSuccess: () => {
      toast.show(`${service.name} updated`, "success");
      qc.invalidateQueries({ queryKey: ["studio", "services"] });
      qc.invalidateQueries({ queryKey: ["artist"] });
      qc.invalidateQueries({ queryKey: ["parlour"] });
    },
    onError: (e: any) => toast.show(e?.message ?? "Could not save", "error"),
  });

  const onSave = () => {
    if (!Number.isFinite(priceNum) || priceNum < 0) return toast.show("Enter a valid price", "error");
    let dep: number | null = null;
    if (deposit.trim() !== "") {
      dep = parseFloat(deposit);
      if (!Number.isFinite(dep) || dep < 0) return toast.show("Enter a valid deposit", "error");
      if (dep > priceNum) return toast.show("The deposit can't be more than the price", "error");
      if (dep > 0 && dep < 0.5) return toast.show("The deposit must be $0 (none) or at least $0.50", "error");
    }
    save.mutate({ price: priceNum, deposit: dep });
  };

  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <Text style={styles.name}>{service.name}</Text>
        <Text style={styles.meta}>{service.style} · {service.duration_min} min</Text>
      </View>

      <View style={styles.fields}>
        <View style={styles.field}>
          <Text style={styles.label}>Price</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>$</Text>
            <TextInput
              testID={`price-${service.id}`}
              value={price}
              onChangeText={(t) => setPrice(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
        <View style={styles.field}>
          <Text style={styles.label}>Deposit</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>$</Text>
            <TextInput
              testID={`deposit-${service.id}`}
              value={deposit}
              onChangeText={(t) => setDeposit(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder={String(defaultDeposit)}
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
      </View>

      <Text style={styles.hint}>
        {deposit.trim() === ""
          ? `Default deposit: $${defaultDeposit} (${defaultPercent}%)`
          : parseFloat(deposit) === 0
            ? "No deposit required"
            : `Clients pay a $${deposit} deposit`}
      </Text>

      {dirty ? (
        <PrimaryButton testID={`save-${service.id}`} label="Save changes" onPress={onSave} loading={save.isPending} />
      ) : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 8 },
  backBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border },
  headerTitle: { color: colors.onSurface, fontFamily: fonts.bold, fontSize: 17 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  sub: { color: colors.muted, fontFamily: fonts.body, fontSize: 14, lineHeight: 20 },
  card: { backgroundColor: colors.surfaceSecondary, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.border, gap: 12 },
  cardTop: { gap: 2 },
  name: { color: colors.onSurface, fontFamily: fonts.bold, fontSize: 16 },
  meta: { color: colors.muted, fontFamily: fonts.body, fontSize: 13 },
  fields: { flexDirection: "row", gap: 12 },
  field: { flex: 1, gap: 6 },
  label: { color: colors.onSurfaceSecondary, fontFamily: fonts.medium, fontSize: 13 },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: colors.surfaceTertiary, borderRadius: 12, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border },
  dollar: { color: colors.muted, fontFamily: fonts.medium, fontSize: 15, marginRight: 4 },
  input: { flex: 1, height: 48, color: colors.onSurface, fontFamily: fonts.body, fontSize: 15 },
  hint: { color: colors.muted, fontFamily: fonts.body, fontSize: 13 },
}));
