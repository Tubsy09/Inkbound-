"""InkBound backend tests - artists set their own service prices and deposits."""
import os
from datetime import date, timedelta

import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") if os.environ.get(
    "EXPO_PUBLIC_BACKEND_URL"
) else "https://tattoo-spots.preview.emergentagent.com"

API = f"{BASE_URL}/api"

CUSTOMER = {"email": "customer@inkbound.com", "password": "Passw0rd!"}
ARTIST = {"email": "artist@inkbound.com", "password": "Passw0rd!"}


def auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module")
def customer_token(s):
    r = s.post(f"{API}/auth/login", json=CUSTOMER, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


@pytest.fixture(scope="module")
def artist_token(s):
    r = s.post(f"{API}/auth/login", json=ARTIST, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


@pytest.fixture()
def priced_service(s, artist_token):
    """A priced service on the demo artist's menu; restores its original price/deposit afterwards."""
    r = s.get(f"{API}/studio/services", headers=auth(artist_token), timeout=20)
    assert r.status_code == 200, r.text
    sv = next(x for x in r.json()["services"] if x["price"] > 0)
    yield sv
    s.put(
        f"{API}/studio/services/{sv['id']}",
        headers=auth(artist_token),
        json={"price": sv["price"], "deposit": sv.get("deposit")},
        timeout=20,
    )


def put(s, token, service_id, price, deposit):
    return s.put(
        f"{API}/studio/services/{service_id}", headers=auth(token), json={"price": price, "deposit": deposit}, timeout=20
    )


def free_slot(s, start=300, end=360):
    for offset in range(start, end):
        d = (date.today() + timedelta(days=offset)).isoformat()
        rs = s.get(f"{API}/bookings/slots", params={"artist_id": "ar_1", "date": d}, timeout=20)
        free = next((x["time"] for x in rs.json().get("slots", []) if x["available"]), None)
        if free:
            return d, free
    pytest.skip("No free slot found")


class TestServicePricing:
    def test_list_my_services(self, s, artist_token):
        r = s.get(f"{API}/studio/services", headers=auth(artist_token), timeout=20)
        assert r.status_code == 200
        body = r.json()
        assert body["default_deposit_percent"] > 0
        assert all("deposit_amount" in x for x in body["services"])

    def test_customer_cannot_use_studio_endpoints(self, s, customer_token, priced_service):
        assert s.get(f"{API}/studio/services", headers=auth(customer_token), timeout=20).status_code == 400
        assert put(s, customer_token, priced_service["id"], 10, None).status_code == 400

    def test_set_price_and_fixed_deposit(self, s, artist_token, priced_service):
        r = put(s, artist_token, priced_service["id"], 250, 75)
        assert r.status_code == 200, r.text
        sv = r.json()["service"]
        assert sv["price"] == 250 and sv["deposit"] == 75 and sv["deposit_amount"] == 75
        # visible to clients on the public artist page
        pub = s.get(f"{API}/artists/ar_1", timeout=20).json()["services"]
        assert next(x for x in pub if x["id"] == priced_service["id"])["deposit_amount"] == 75

    def test_deposit_defaults_to_percentage(self, s, artist_token, priced_service):
        r = put(s, artist_token, priced_service["id"], 200, None)
        assert r.status_code == 200
        sv = r.json()["service"]
        assert sv["deposit"] is None
        assert sv["deposit_amount"] == round(200 * 20 / 100, 2)  # assumes DEPOSIT_PERCENT=20 (the default)

    def test_zero_deposit_allowed(self, s, artist_token, priced_service):
        r = put(s, artist_token, priced_service["id"], 120, 0)
        assert r.status_code == 200 and r.json()["service"]["deposit_amount"] == 0

    def test_rejects_bad_values(self, s, artist_token, priced_service):
        sid = priced_service["id"]
        assert put(s, artist_token, sid, -5, None).status_code == 422
        assert put(s, artist_token, sid, 100, -1).status_code == 422
        assert put(s, artist_token, sid, 100, 150).status_code == 400  # deposit > price
        assert put(s, artist_token, sid, 100, 0.2).status_code == 400  # under the $0.50 minimum
        assert put(s, artist_token, sid, 999999, None).status_code == 422

    def test_cannot_edit_another_studios_service(self, s, artist_token):
        r = put(s, artist_token, "sv_pl_2_0", 1, None)
        assert r.status_code == 404

    def test_new_booking_snapshots_price_and_deposit(self, s, customer_token, artist_token, priced_service):
        assert put(s, artist_token, priced_service["id"], 300, 90).status_code == 200
        d, t = free_slot(s)
        r = s.post(
            f"{API}/bookings",
            headers=auth(customer_token),
            json={"artist_id": "ar_1", "service_id": priced_service["id"], "date": d, "time": t, "note": "TEST_pricing"},
            timeout=20,
        )
        assert r.status_code == 200, r.text
        bk = r.json()["booking"]
        assert bk["price"] == 300 and bk["deposit_amount"] == 90
        # changing the price afterwards doesn't change the booking already made
        assert put(s, artist_token, priced_service["id"], 500, 200).status_code == 200
        mine = s.get(f"{API}/bookings/me", headers=auth(customer_token), timeout=20).json()["bookings"]
        same = next(b for b in mine if b["id"] == bk["id"])
        assert same["price"] == 300 and same["deposit_amount"] == 90
