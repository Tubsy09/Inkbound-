"""Unit tests for the deposit refund policy. Pure logic: no server, database or network needed."""
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from policy import appointment_start, refund_decision  # noqa: E402

NOW = datetime(2026, 10, 2, 12, 0, tzinfo=timezone.utc)


def decide(by, hours_ahead, deposit=50, window=48):
    return refund_decision(
        cancelled_by=by, deposit_amount=deposit, starts_at=NOW + timedelta(hours=hours_ahead), now=NOW, window_hours=window
    )


def test_client_cancels_well_in_advance_gets_full_refund():
    assert decide("client", 72) == (50.0, "cancelled_in_time")


def test_client_cancels_exactly_at_cutoff_gets_full_refund():
    assert decide("client", 48) == (50.0, "cancelled_in_time")


def test_client_cancels_late_loses_deposit():
    assert decide("client", 47.9) == (0.0, "late_cancellation")
    assert decide("client", 1) == (0.0, "late_cancellation")


def test_client_cancels_after_appointment_time_loses_deposit():
    assert decide("client", -2) == (0.0, "late_cancellation")


def test_artist_cancel_is_always_a_full_refund():
    assert decide("artist", 72) == (50.0, "artist_cancelled")
    assert decide("artist", 1) == (50.0, "artist_cancelled")
    assert decide("artist", -5) == (50.0, "artist_cancelled")


def test_no_deposit_means_nothing_to_refund():
    assert decide("client", 72, deposit=0) == (0.0, "no_deposit")
    assert decide("artist", 72, deposit=None) == (0.0, "no_deposit")


def test_amount_is_rounded_to_pence():
    assert decide("artist", 72, deposit=12.349)[0] == 12.35


def test_custom_window():
    assert decide("client", 30, window=24) == (50.0, "cancelled_in_time")
    assert decide("client", 30, window=72) == (0.0, "late_cancellation")


def test_appointment_start_parses_date_and_time():
    dt = appointment_start("2026-10-09", "14:00")
    assert (dt.year, dt.month, dt.day, dt.hour, dt.minute) == (2026, 10, 9, 14, 0)
    assert dt.tzinfo is not None
