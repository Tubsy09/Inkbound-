// Clients who cancel at least this many hours before their appointment get their deposit back;
// later than that the deposit is kept. If the artist cancels, the deposit is always refunded.
// Keep in sync with REFUND_WINDOW_HOURS in backend/server.py (the server makes the actual decision).
export const CANCEL_WINDOW_HOURS = 48;
