import React from "react";

// One currency for the whole app: artists enter prices in it and the deposit is charged in it
// (see CURRENCY in backend/server.py). Everyone sees the same amounts, so nobody is shown a
// local symbol on a number that was never converted.
const SYMBOL = "£";
const CODE = "GBP";
const ICON = "currency-gbp" as const; // MaterialCommunityIcons name

export function formatMoney(n: number | undefined | null): string {
  const v = Number(n ?? 0);
  const num = Number.isInteger(v)
    ? v.toLocaleString()
    : v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${SYMBOL}${num}`;
}

const value = { symbol: SYMBOL, code: CODE, icon: ICON, fmt: formatMoney };

export function useCurrency() {
  return value;
}

// Kept so existing imports and the app layout keep working; it no longer holds any state.
export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
