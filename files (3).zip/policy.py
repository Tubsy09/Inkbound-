"""Deposit cancellation / refund policy.

Pure functions (no database, no network) so the rules are easy to read, test and change.

The rules:
  * If the ARTIST cancels or declines, the client always gets the full deposit back.
  * If the CLIENT cancels at least `window_hours` before the appointment, they get the full deposit back.
  * If the CLIENT cancels later than that, the deposit is kept by the artist.
"""
from datetime import datetime, timedelta, timezone

DEFAULT_REFUND_WINDOW_HOURS = 48.0


def appointment_start(date_str: str, time_str: str) -> datetime:
    """Booking date + time as a datetime.

    Studios' time zones aren't stored, so the slot is treated as UTC. For a UK studio that is
    within an hour of local time, which is fine for a 48-hour cut-off.
    """
    dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    return dt.replace(tzinfo=timezone.utc)


def refund_decision(
    *,
    cancelled_by: str,  # "artist" or "client"
    deposit_amount: float,
    starts_at: datetime,
    now: datetime,
    window_hours: float = DEFAULT_REFUND_WINDOW_HOURS,
):
    """Returns (refund_amount, reason)."""
    amount = round(float(deposit_amount or 0), 2)
    if amount <= 0:
        return 0.0, "no_deposit"
    if cancelled_by == "artist":
        return amount, "artist_cancelled"
    if starts_at - now >= timedelta(hours=window_hours):
        return amount, "cancelled_in_time"
    return 0.0, "late_cancellation"
