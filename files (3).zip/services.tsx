import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api/client";
import { Icon } from "@/src/components/Icon";
import { useToast } from "@/src/components/toast";
import { PrimaryButton } from "@/src/components/ui";
import { useCurrency } from "@/src/currency";
import { Service } from "@/src/types";
import { fonts, makeStyles, useTheme } from "@/src/theme";

type Data = { services: Service[]; default_deposit_percent: number };

function cleanMoney(t: string) {
  const v = t.replace(/[^0-9.]/g, "");
  const [whole, ...rest] = v.split(".");
  return rest.length ? `${whole}.${rest.join("").slice(0, 2)}` : whole;
}

type ServiceBody = { name: string; price: number; deposit: number | null };

/** Check what the artist typed. Returns the request body, or an error message to show. */
function parseServiceForm(
  name: string,
  price: string,
  deposit: string,
  symbol: string,
): { body: ServiceBody; error?: undefined } | { error: string; body?: undefined } {
  if (!name.trim()) return { error: "Give the service a name" };
  const priceNum = parseFloat(price);
  if (price.trim() === "" || !Number.isFinite(priceNum) || priceNum < 0) return { error: "Enter a valid price" };
  let dep: number | null = null;
  if (deposit.trim() !== "") {
    dep = parseFloat(deposit);
    if (!Number.isFinite(dep) || dep < 0) return { error: "Enter a valid deposit" };
    if (dep > priceNum) return { error: "The deposit can't be more than the price" };
    if (dep > 0 && dep < 0.5) return { error: `The deposit must be ${symbol}0 (none) or at least ${symbol}0.50` };
  }
  return { body: { name: name.trim(), price: priceNum, deposit: dep } };
}

export default function StudioServices() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["studio", "services"],
    queryFn: () => api<Data>("/api/studio/services"),
  });

  // A new service is only a local draft until the artist fills it in and taps "Add service",
  // so a half-finished service is never visible to clients.
  const [adding, setAdding] = useState(false);

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Pressable testID="services-back" onPress={() => router.back()} style={styles.backBtn}>
          <Icon name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={styles.headerTitle}>Prices & deposits</Text>
        <Pressable testID="add-service" onPress={() => setAdding(true)} disabled={adding} style={[styles.backBtn, adding && { opacity: 0.4 }]}>
          <Icon name="plus" size={22} color={colors.brandPrimary} />
        </Pressable>
      </View>

      {isLoading || !data ? (
        <View style={styles.center}><ActivityIndicator color={colors.brandPrimary} size="large" /></View>
      ) : (
        <KeyboardAwareScrollView
          contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 40, gap: 14 }}
          showsVerticalScrollIndicator={false}
          bottomOffset={20}
        >
          <Text style={styles.sub}>
            Name each service, set what you charge and the deposit clients pay to secure a slot. Leave the deposit empty to
            use the default ({data.default_deposit_percent}% of the price). New prices only apply to future bookings.
          </Text>
          {data.services.map((sv) => (
            <ServiceRow key={sv.id} service={sv} defaultPercent={data.default_deposit_percent} canDelete={data.services.length > 1} />
          ))}
          {adding ? (
            <NewServiceCard defaultPercent={data.default_deposit_percent} onDone={() => setAdding(false)} />
          ) : (
            <Pressable testID="add-service-bottom" style={styles.addRow} onPress={() => setAdding(true)}>
              <Icon name="plus-circle-outline" size={20} color={colors.brandPrimary} />
              <Text style={styles.addRowText}>Add a service</Text>
            </Pressable>
          )}
        </KeyboardAwareScrollView>
      )}
    </View>
  );
}

function ServiceRow({ service, defaultPercent, canDelete }: { service: Service; defaultPercent: number; canDelete: boolean }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const qc = useQueryClient();
  const { symbol, fmt } = useCurrency();

  const savedName = service.name ?? "";
  const savedPrice = String(service.price ?? 0);
  const savedDeposit = service.deposit == null ? "" : String(service.deposit);
  const [name, setName] = useState(savedName);
  const [price, setPrice] = useState(savedPrice);
  const [deposit, setDeposit] = useState(savedDeposit);

  useEffect(() => {
    setName(savedName);
    setPrice(savedPrice);
    setDeposit(savedDeposit);
  }, [savedName, savedPrice, savedDeposit]);

  const priceNum = parseFloat(price);
  const dirty = name !== savedName || price !== savedPrice || deposit !== savedDeposit;
  const defaultDeposit = Number.isFinite(priceNum) ? Math.round(priceNum * defaultPercent) / 100 : 0;

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["studio", "services"] });
    qc.invalidateQueries({ queryKey: ["artist"] });
    qc.invalidateQueries({ queryKey: ["parlour"] });
  };

  const save = useMutation({
    mutationFn: (body: { name: string; price: number; deposit: number | null }) =>
      api(`/api/studio/services/${service.id}`, { method: "PUT", body: JSON.stringify(body) }),
    onSuccess: () => {
      toast.show(`${name} updated`, "success");
      invalidate();
    },
    onError: (e: any) => toast.show(e?.message ?? "Could not save", "error"),
  });

  const del = useMutation({
    mutationFn: () => api(`/api/studio/services/${service.id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.show("Service removed", "info");
      invalidate();
    },
    onError: (e: any) => toast.show(e?.message ?? "Could not remove", "error"),
  });

  const onSave = () => {
    const parsed = parseServiceForm(name, price, deposit, symbol);
    if (parsed.error) return toast.show(parsed.error, "error");
    save.mutate(parsed.body);
  };

  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <TextInput
          testID={`name-${service.id}`}
          value={name}
          onChangeText={setName}
          placeholder="Service name"
          placeholderTextColor={colors.muted}
          style={styles.nameInput}
        />
        {canDelete ? (
          <Pressable testID={`delete-${service.id}`} hitSlop={8} onPress={() => del.mutate()} style={styles.deleteBtn}>
            <Icon name="trash-can-outline" size={18} color={colors.onSurfaceSecondary} />
          </Pressable>
        ) : null}
      </View>
      <Text style={styles.meta}>{service.style} · {service.duration_min} min</Text>

      <View style={styles.fields}>
        <View style={styles.field}>
          <Text style={styles.label}>Price</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>{symbol.trim()}</Text>
            <TextInput
              testID={`price-${service.id}`}
              value={price}
              onChangeText={(t) => setPrice(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
        <View style={styles.field}>
          <Text style={styles.label}>Deposit</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>{symbol.trim()}</Text>
            <TextInput
              testID={`deposit-${service.id}`}
              value={deposit}
              onChangeText={(t) => setDeposit(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder={String(defaultDeposit)}
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
      </View>

      <Text style={styles.hint}>
        {deposit.trim() === ""
          ? `Default deposit: ${fmt(defaultDeposit)} (${defaultPercent}%)`
          : parseFloat(deposit) === 0
            ? "No deposit required"
            : `Clients pay a ${fmt(parseFloat(deposit))} deposit`}
      </Text>

      {dirty ? (
        <PrimaryButton testID={`save-${service.id}`} label="Save changes" onPress={onSave} loading={save.isPending} />
      ) : null}
    </View>
  );
}

function NewServiceCard({ defaultPercent, onDone }: { defaultPercent: number; onDone: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const qc = useQueryClient();
  const { symbol, fmt } = useCurrency();

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [deposit, setDeposit] = useState("");

  const priceNum = parseFloat(price);
  const defaultDeposit = Number.isFinite(priceNum) ? Math.round(priceNum * defaultPercent) / 100 : 0;

  const create = useMutation({
    mutationFn: (body: ServiceBody) =>
      api("/api/studio/services", { method: "POST", body: JSON.stringify({ ...body, style: "All", duration_min: 60 }) }),
    onSuccess: (_d, body) => {
      toast.show(`${body.name} added`, "success");
      qc.invalidateQueries({ queryKey: ["studio", "services"] });
      qc.invalidateQueries({ queryKey: ["artist"] });
      qc.invalidateQueries({ queryKey: ["parlour"] });
      onDone();
    },
    onError: (e: any) => toast.show(e?.message ?? "Could not add", "error"),
  });

  const onAdd = () => {
    const parsed = parseServiceForm(name, price, deposit, symbol);
    if (parsed.error) return toast.show(parsed.error, "error");
    create.mutate(parsed.body);
  };

  return (
    <View style={[styles.card, { borderColor: colors.brandPrimary }]}>
      <Text style={styles.label}>New service</Text>
      <TextInput
        testID="new-service-name"
        value={name}
        onChangeText={setName}
        placeholder="Service name, e.g. Small fine line piece"
        placeholderTextColor={colors.muted}
        style={styles.nameInput}
        autoFocus
      />

      <View style={styles.fields}>
        <View style={styles.field}>
          <Text style={styles.label}>Price</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>{symbol.trim()}</Text>
            <TextInput
              testID="new-service-price"
              value={price}
              onChangeText={(t) => setPrice(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
        <View style={styles.field}>
          <Text style={styles.label}>Deposit</Text>
          <View style={styles.inputWrap}>
            <Text style={styles.dollar}>{symbol.trim()}</Text>
            <TextInput
              testID="new-service-deposit"
              value={deposit}
              onChangeText={(t) => setDeposit(cleanMoney(t))}
              keyboardType="decimal-pad"
              placeholder={String(defaultDeposit)}
              placeholderTextColor={colors.muted}
              style={styles.input}
            />
          </View>
        </View>
      </View>

      <Text style={styles.hint}>
        {deposit.trim() === ""
          ? `Default deposit: ${fmt(defaultDeposit)} (${defaultPercent}%). Enter 0 as the price for a free service.`
          : parseFloat(deposit) === 0
            ? "No deposit required"
            : `Clients pay a ${fmt(parseFloat(deposit) || 0)} deposit`}
      </Text>

      <PrimaryButton testID="new-service-save" label="Add service" onPress={onAdd} loading={create.isPending} />
      <Pressable testID="new-service-cancel" onPress={onDone} style={styles.cancelRow} disabled={create.isPending}>
        <Text style={styles.cancelText}>Cancel</Text>
      </Pressable>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 8 },
  backBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: colors.border },
  headerTitle: { color: colors.onSurface, fontFamily: fonts.bold, fontSize: 17 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  sub: { color: colors.muted, fontFamily: fonts.body, fontSize: 14, lineHeight: 20 },
  card: { backgroundColor: colors.surfaceSecondary, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: colors.border, gap: 10 },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 10 },
  nameInput: { flex: 1, color: colors.onSurface, fontFamily: fonts.bold, fontSize: 16, paddingVertical: 4, borderBottomWidth: 1, borderBottomColor: colors.divider },
  deleteBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  meta: { color: colors.muted, fontFamily: fonts.body, fontSize: 13 },
  fields: { flexDirection: "row", gap: 12 },
  field: { flex: 1, gap: 6 },
  label: { color: colors.onSurfaceSecondary, fontFamily: fonts.medium, fontSize: 13 },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: colors.surfaceTertiary, borderRadius: 12, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border },
  dollar: { color: colors.muted, fontFamily: fonts.medium, fontSize: 15, marginRight: 4 },
  input: { flex: 1, height: 48, color: colors.onSurface, fontFamily: fonts.body, fontSize: 15 },
  hint: { color: colors.muted, fontFamily: fonts.body, fontSize: 13 },
  addRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 16, borderRadius: 16, borderWidth: 1, borderStyle: "dashed", borderColor: colors.borderStrong, backgroundColor: colors.surfaceSecondary },
  cancelRow: { alignItems: "center", paddingVertical: 8 },
  cancelText: { color: colors.onSurfaceSecondary, fontFamily: fonts.medium, fontSize: 14 },
  addRowText: { color: colors.brandPrimary, fontFamily: fonts.medium, fontSize: 15 },
}));
