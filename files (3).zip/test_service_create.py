"""InkBound backend tests - creating services (validation, visibility, clean-up)."""
import os

import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") if os.environ.get(
    "EXPO_PUBLIC_BACKEND_URL"
) else "https://tattoo-spots.preview.emergentagent.com"

API = f"{BASE_URL}/api"
ARTIST = {"email": "artist@inkbound.com", "password": "Passw0rd!"}


def auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module")
def artist_token(s):
    r = s.post(f"{API}/auth/login", json=ARTIST, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


def create(s, token, **body):
    payload = {"name": "TEST_service", "price": 80, "deposit": 20, **body}
    return s.post(f"{API}/studio/services", headers=auth(token), json=payload, timeout=20)


class TestCreateService:
    def test_blank_name_rejected(self, s, artist_token):
        assert create(s, artist_token, name="   ").status_code == 400
        assert create(s, artist_token, name="").status_code == 422

    def test_deposit_rules_apply_on_create(self, s, artist_token):
        assert create(s, artist_token, price=50, deposit=80).status_code == 400  # more than the price
        assert create(s, artist_token, price=50, deposit=0.2).status_code == 400  # under the minimum
        assert create(s, artist_token, price=-1, deposit=None).status_code == 422

    def test_create_show_then_delete(self, s, artist_token):
        r = create(s, artist_token, name="  TEST_fresh piece  ", price=120, deposit=None)
        assert r.status_code == 200, r.text
        sv = r.json()["service"]
        assert sv["name"] == "TEST_fresh piece"  # trimmed
        assert sv["deposit"] is None and sv["deposit_amount"] > 0
        try:
            mine = s.get(f"{API}/studio/services", headers=auth(artist_token), timeout=20).json()["services"]
            assert any(x["id"] == sv["id"] for x in mine)
            public = s.get(f"{API}/artists/ar_1", timeout=20).json()["services"]
            assert any(x["id"] == sv["id"] for x in public)
        finally:
            d = s.delete(f"{API}/studio/services/{sv['id']}", headers=auth(artist_token), timeout=20)
            assert d.status_code == 200
        public = s.get(f"{API}/artists/ar_1", timeout=20).json()["services"]
        assert not any(x["id"] == sv["id"] for x in public)

    def test_free_service_allowed(self, s, artist_token):
        r = create(s, artist_token, name="TEST_free chat", price=0, deposit=None)
        assert r.status_code == 200, r.text
        sv = r.json()["service"]
        assert sv["price"] == 0 and sv["deposit_amount"] == 0
        s.delete(f"{API}/studio/services/{sv['id']}", headers=auth(artist_token), timeout=20)
