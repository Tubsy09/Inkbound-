import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { ActivityIndicator, FlatList, Platform, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api/client";
import { createDeposit, openDeposit, pollStatus } from "@/src/api/payments";
import { BookingCard } from "@/src/components/BookingCard";
import { Icon } from "@/src/components/Icon";
import { useToast } from "@/src/components/toast";
import { usesNativeTabs } from "@/src/navigation";
import { useCurrency } from "@/src/currency";
import { CANCEL_WINDOW_HOURS } from "@/src/policy";
import { confirmAction } from "@/src/utils/confirm";
import { fonts, makeStyles, useTheme } from "@/src/theme";
import type { Booking } from "@/src/types";

export default function Bookings() {
  const styles = useStyles();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const toast = useToast();
  const qc = useQueryClient();
  const { fmt } = useCurrency();
  const bottomChrome = usesNativeTabs ? insets.bottom : 0;

  const { data, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["bookings", "me"],
    queryFn: () => api<{ bookings: Booking[] }>("/api/bookings/me"),
  });

  const cancel = useMutation({
    mutationFn: (id: string) =>
      api<{ booking: Booking }>(`/api/bookings/${id}/status`, { method: "PATCH", body: JSON.stringify({ status: "cancelled" }) }),
    onSuccess: ({ booking }) => {
      toast.show(
        booking.refund_status === "due"
          ? `Booking cancelled — your ${fmt(booking.refund_amount ?? 0)} deposit will be refunded`
          : booking.deposit_paid
            ? "Booking cancelled — your deposit isn't refundable this close to the appointment"
            : "Booking cancelled",
        "info",
      );
      qc.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: (e: any) => toast.show(e?.message ?? "Could not cancel", "error"),
  });

  const askCancel = (b: Booking) => {
    let message = "Are you sure you want to cancel this appointment?";
    if (b.deposit_paid) {
      message +=
        (b.cancel_refund ?? 0) > 0
          ? ` You'll get your ${fmt(b.cancel_refund ?? 0)} deposit back.`
          : ` Your ${fmt(b.deposit_amount ?? 0)} deposit won't be refunded because it's less than ${CANCEL_WINDOW_HOURS} hours before your appointment.`;
    }
    confirmAction("Cancel booking?", message, "Cancel booking", () => cancel.mutate(b.id));
  };

  const payDeposit = async (booking: Booking) => {
    try {
      toast.show("Opening secure checkout…", "info");
      const session = await createDeposit(booking.id);
      await openDeposit(session.url);
      if (Platform.OS !== "web") {
        // On native the browser closes and returns here; verify via polling.
        const result = await pollStatus(session.session_id);
        qc.invalidateQueries({ queryKey: ["bookings"] });
        toast.show(
          result.payment_status === "paid" ? "Deposit paid — your slot is secured!" : "Payment not completed",
          result.payment_status === "paid" ? "success" : "info",
        );
      }
      // On web the page navigates to Stripe and returns to /payment-result.
    } catch (e: any) {
      toast.show(e?.message ?? "Could not start payment", "error");
    }
  };

  const bookings = data?.bookings ?? [];

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <Text style={styles.title}>My Bookings</Text>
        <Text style={styles.subtitle}>{bookings.length} appointment{bookings.length === 1 ? "" : "s"}</Text>
      </View>

      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.brandPrimary} size="large" />
        </View>
      ) : bookings.length === 0 ? (
        <View style={styles.center}>
          <Icon name="calendar-heart" size={44} color={colors.muted} />
          <Text style={styles.emptyTitle}>No bookings yet</Text>
          <Text style={styles.emptySub}>Find a studio and book your next piece.</Text>
          <Pressable testID="discover-cta" style={styles.cta} onPress={() => router.push("/(tabs)")}>
            <Text style={styles.ctaText}>Discover studios</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={bookings}
          keyExtractor={(b) => b.id}
          renderItem={({ item }) => (
            <BookingCard
              booking={item}
              perspective="customer"
              actions={(() => {
                const acts: { label: string; onPress: () => void; variant?: "confirm" | "decline" }[] = [];
                // The deposit is paid after the artist confirms, so nobody pays for a request that gets declined.
                if (!item.deposit_paid && item.deposit_amount && item.status === "confirmed") {
                  acts.push({ label: "Pay Deposit", onPress: () => payDeposit(item), variant: "confirm" });
                }
                if (["pending", "confirmed"].includes(item.status)) {
                  acts.push({ label: "Cancel", onPress: () => askCancel(item), variant: "decline" });
                }
                return acts.length ? acts : undefined;
              })()}
            />
          )}
          contentContainerStyle={{ padding: 20, paddingTop: 8, paddingBottom: bottomChrome + 24, gap: 14 }}
          showsVerticalScrollIndicator={false}
          onRefresh={refetch}
          refreshing={isRefetching}
        />
      )}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  title: { color: colors.onSurface, fontFamily: fonts.display, fontSize: 30 },
  subtitle: { color: colors.muted, fontFamily: fonts.body, fontSize: 14, marginTop: 4 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 8, padding: 24 },
  emptyTitle: { color: colors.onSurface, fontFamily: fonts.medium, fontSize: 17, marginTop: 6 },
  emptySub: { color: colors.muted, fontFamily: fonts.body, fontSize: 14, textAlign: "center" },
  cta: { marginTop: 16, backgroundColor: colors.brandPrimary, borderRadius: 12, paddingHorizontal: 24, paddingVertical: 14 },
  ctaText: { color: colors.onBrandPrimary, fontFamily: fonts.bold, fontSize: 15 },
}));
