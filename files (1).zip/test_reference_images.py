"""InkBound backend tests - reference images attached to bookings."""
import base64
import os
from datetime import date, timedelta

import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") if os.environ.get(
    "EXPO_PUBLIC_BACKEND_URL"
) else "https://tattoo-spots.preview.emergentagent.com"

API = f"{BASE_URL}/api"

CUSTOMER = {"email": "customer@inkbound.com", "password": "Passw0rd!"}
ARTIST = {"email": "artist@inkbound.com", "password": "Passw0rd!"}

# 1x1 transparent PNG
PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
)


def auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module")
def customer_token(s):
    r = s.post(f"{API}/auth/login", json=CUSTOMER, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


@pytest.fixture(scope="module")
def artist_token(s):
    r = s.post(f"{API}/auth/login", json=ARTIST, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["session_token"]


def upload(s, token):
    r = s.post(f"{API}/upload", headers=auth(token), files={"file": ("ref.png", PNG, "image/png")}, timeout=60)
    assert r.status_code == 200, r.text
    return r.json()["url"]  # relative: /api/files/...


def free_slot(s, artist_id="ar_1", start=70, end=110):
    for offset in range(start, end):
        d = (date.today() + timedelta(days=offset)).isoformat()
        rs = s.get(f"{API}/bookings/slots", params={"artist_id": artist_id, "date": d}, timeout=20)
        free = next((x["time"] for x in rs.json().get("slots", []) if x["available"]), None)
        if free:
            return d, free
    pytest.skip("No free slot found")


def book(s, token, d, t, refs):
    return s.post(
        f"{API}/bookings",
        headers=auth(token),
        json={"artist_id": "ar_1", "service_id": "sv_pl_1_0", "date": d, "time": t, "note": "TEST_refs", "reference_images": refs},
        timeout=20,
    )


class TestReferenceImages:
    def test_booking_without_images_still_works(self, s, customer_token):
        d, t = free_slot(s)
        r = book(s, customer_token, d, t, [])
        assert r.status_code == 200, r.text
        assert r.json()["booking"]["reference_images"] == []

    def test_attach_images_and_artist_sees_them(self, s, customer_token, artist_token):
        d, t = free_slot(s, start=111, end=150)
        url = upload(s, customer_token)
        # accept both relative and absolute forms
        r = book(s, customer_token, d, t, [url, f"{BASE_URL}{url}"])
        assert r.status_code == 200, r.text
        bk = r.json()["booking"]
        assert bk["reference_images"] == [url]  # normalised + de-duplicated

        ra = s.get(f"{API}/bookings/artist", headers=auth(artist_token), timeout=20)
        mine = next(b for b in ra.json()["bookings"] if b["id"] == bk["id"])
        assert mine["reference_images"] == [url]

        # the image is actually retrievable
        rf = s.get(f"{BASE_URL}{url}", timeout=30)
        assert rf.status_code == 200

    def test_external_url_rejected(self, s, customer_token):
        d, t = free_slot(s, start=151, end=190)
        r = book(s, customer_token, d, t, ["https://example.com/tracker.png"])
        assert r.status_code == 400

    def test_other_users_upload_rejected(self, s, customer_token, artist_token):
        d, t = free_slot(s, start=191, end=230)
        artists_url = upload(s, artist_token)
        r = book(s, customer_token, d, t, [artists_url])
        assert r.status_code == 400

    def test_more_than_four_rejected(self, s, customer_token):
        d, t = free_slot(s, start=231, end=270)
        urls = [upload(s, customer_token) for _ in range(5)]
        r = book(s, customer_token, d, t, urls)
        assert r.status_code == 400
