import { Image } from "expo-image";
import { useState } from "react";
import { Modal, Pressable, ScrollView, Text, View } from "react-native";

import { Icon } from "@/src/components/Icon";
import { StatusBadge } from "@/src/components/ui";
import { fonts, makeStyles, useTheme } from "@/src/theme";
import type { Booking } from "@/src/types";

const BACKEND = process.env.EXPO_PUBLIC_BACKEND_URL;
const refUrl = (u: string) => (u.startsWith("http") ? u : `${BACKEND}${u}`);

function formatDate(iso: string) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export function BookingCard({
  booking,
  perspective,
  actions,
}: {
  booking: Booking;
  perspective: "customer" | "artist";
  actions?: { label: string; onPress: () => void; variant?: "confirm" | "decline" }[];
}) {
  const styles = useStyles();
  const { colors } = useTheme();
  const title = perspective === "customer" ? booking.artist_name : booking.customer_name || "Client";
  const avatar = booking.artist_avatar;
  const refs = booking.reference_images ?? [];
  const [viewing, setViewing] = useState<string | null>(null);

  return (
    <View style={styles.card} testID={`booking-card-${booking.id}`}>
      <View style={styles.top}>
        {perspective === "customer" && avatar ? (
          <Image source={{ uri: avatar }} style={styles.avatar} contentFit="cover" />
        ) : (
          <View style={styles.avatarFallback}>
            <Icon name={perspective === "customer" ? "brush-variant" : "account"} size={20} color={colors.brandPrimary} />
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{title}</Text>
          <Text style={styles.sub} numberOfLines={1}>
            {booking.service_name} · {booking.parlour_name}
          </Text>
        </View>
        <StatusBadge status={booking.status} />
      </View>

      <View style={styles.metaRow}>
        <View style={styles.metaItem}>
          <Icon name="calendar-blank-outline" size={15} color={colors.muted} />
          <Text style={styles.metaText}>{formatDate(booking.date)}</Text>
        </View>
        <View style={styles.metaItem}>
          <Icon name="clock-outline" size={15} color={colors.muted} />
          <Text style={styles.metaText}>{booking.time}</Text>
        </View>
        <View style={styles.metaItem}>
          <Icon name="currency-usd" size={15} color={colors.muted} />
          <Text style={styles.metaText}>{booking.price === 0 ? "Free" : booking.price}</Text>
        </View>
      </View>

      {booking.note ? <Text style={styles.note}>“{booking.note}”</Text> : null}

      {refs.length ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.refRow}>
          {refs.map((u) => (
            <Pressable key={u} testID={`booking-ref-${booking.id}`} onPress={() => setViewing(refUrl(u))}>
              <Image source={{ uri: refUrl(u) }} style={styles.refThumb} contentFit="cover" />
            </Pressable>
          ))}
        </ScrollView>
      ) : null}

      <Modal visible={!!viewing} transparent animationType="fade" onRequestClose={() => setViewing(null)}>
        <Pressable style={styles.viewer} onPress={() => setViewing(null)}>
          {viewing ? <Image source={{ uri: viewing }} style={styles.viewerImg} contentFit="contain" /> : null}
          <View style={styles.viewerClose}>
            <Icon name="close" size={22} color={colors.onSurface} />
          </View>
        </Pressable>
      </Modal>

      {perspective === "customer" && booking.deposit_amount ? (
        <View style={styles.depositRow}>
          <Icon
            name={booking.deposit_paid ? "check-decagram" : "cash-clock"}
            size={15}
            color={booking.deposit_paid ? colors.success : colors.brandPrimary}
          />
          <Text style={[styles.depositText, booking.deposit_paid && { color: colors.success }]}>
            {booking.deposit_paid
              ? `Deposit paid · $${booking.deposit_amount}`
              : `Deposit $${booking.deposit_amount} to secure this slot`}
          </Text>
        </View>
      ) : null}

      {actions && actions.length ? (
        <View style={styles.actions}>
          {actions.map((a) => (
            <Pressable
              key={a.label}
              testID={`booking-action-${a.label.toLowerCase()}-${booking.id}`}
              onPress={a.onPress}
              style={[
                styles.actionBtn,
                a.variant === "confirm" && styles.confirmBtn,
                a.variant === "decline" && styles.declineBtn,
              ]}
            >
              <Text
                style={[
                  styles.actionText,
                  a.variant === "confirm" && { color: colors.onBrandPrimary },
                  a.variant === "decline" && { color: colors.onError },
                ]}
              >
                {a.label}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  card: {
    backgroundColor: colors.surfaceSecondary,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
  },
  top: { flexDirection: "row", alignItems: "center", gap: 12 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.surfaceTertiary },
  avatarFallback: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.brandTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  name: { color: colors.onSurface, fontFamily: fonts.bold, fontSize: 15 },
  sub: { color: colors.muted, fontFamily: fonts.body, fontSize: 13, marginTop: 2 },
  metaRow: { flexDirection: "row", gap: 18 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 5 },
  metaText: { color: colors.onSurfaceSecondary, fontFamily: fonts.medium, fontSize: 13 },
  note: { color: colors.onSurfaceSecondary, fontFamily: fonts.body, fontSize: 13, fontStyle: "italic" },
  refRow: { gap: 8 },
  refThumb: { width: 64, height: 64, borderRadius: 10, backgroundColor: colors.surfaceTertiary },
  viewer: { flex: 1, backgroundColor: "rgba(0,0,0,0.92)", alignItems: "center", justifyContent: "center" },
  viewerImg: { width: "100%", height: "80%" },
  viewerClose: { position: "absolute", top: 56, right: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  depositRow: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.surfaceTertiary, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
  depositText: { color: colors.onSurfaceSecondary, fontFamily: fonts.medium, fontSize: 13, flex: 1 },
  actions: { flexDirection: "row", gap: 10 },
  actionBtn: {
    flex: 1,
    height: 42,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surfaceTertiary,
    borderWidth: 1,
    borderColor: colors.border,
  },
  confirmBtn: { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary },
  declineBtn: { backgroundColor: colors.error, borderColor: colors.error },
  actionText: { fontFamily: fonts.bold, fontSize: 14, color: colors.onSurface },
}));
