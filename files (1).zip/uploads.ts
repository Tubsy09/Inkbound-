import * as ImagePicker from "expo-image-picker";
import { Alert, Linking, Platform } from "react-native";

import { getAuthToken } from "@/src/api/client";

const BASE = process.env.EXPO_PUBLIC_BACKEND_URL;

// Requests library permission with a graceful, contextual flow.
async function ensureLibraryPermission(message: string): Promise<boolean> {
  const current = await ImagePicker.getMediaLibraryPermissionsAsync();
  if (current.granted) return true;
  if (current.canAskAgain) {
    const req = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (req.granted) return true;
  }
  // Permanently blocked
  Alert.alert(
    "Photo access needed",
    message,
    [
      { text: "Cancel", style: "cancel" },
      { text: "Open Settings", onPress: () => Linking.openSettings() },
    ],
  );
  return false;
}

export type UploadResult = { path: string; url: string };

// Picks one image and uploads it to the backend object-storage endpoint.
// Returns the absolute display URL, or null if cancelled/denied.
export async function pickAndUpload(
  token: string | null,
  opts: { crop?: boolean; permissionMessage?: string } = {},
): Promise<string | null> {
  const { crop = true, permissionMessage = "Allow photo access to upload portfolio images." } = opts;
  const ok = await ensureLibraryPermission(permissionMessage);
  if (!ok) return null;

  const res = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["images"],
    quality: 0.7,
    // Portfolio/cover photos are cropped 4:3; reference images are sent uncropped.
    ...(crop ? { allowsEditing: true, aspect: [4, 3] as [number, number] } : {}),
  });
  if (res.canceled || !res.assets?.length) return null;

  const asset = res.assets[0];
  const name = asset.fileName || `photo_${Date.now()}.jpg`;
  const type = asset.mimeType || "image/jpeg";

  const form = new FormData();
  if (Platform.OS === "web") {
    const blob = await (await fetch(asset.uri)).blob();
    form.append("file", blob, name);
  } else {
    form.append("file", { uri: asset.uri, name, type } as any);
  }

  const headers: Record<string, string> = {};
  const authToken = token ?? getAuthToken();
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  const r = await fetch(`${BASE}/api/upload`, { method: "POST", headers, body: form });
  if (!r.ok) throw new Error("Upload failed");
  const data: UploadResult = await r.json();
  return `${BASE}${data.url}`;
}
